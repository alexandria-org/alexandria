#!/bin/bash

cd `dirname $0`

wget https://github.com/alexandria-org/alexandria/releases/latest/download/alexandria.zip -O alexandria.zip
unzip -o alexandria.zip

